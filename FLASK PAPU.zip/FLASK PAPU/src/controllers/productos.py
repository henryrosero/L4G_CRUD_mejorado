from flask import render_template, request, redirect, url_for
from src import app
from src.models.productos import ProductosModel

@app.route('/productos')
def productos():
    productosModel = ProductosModel()

    productos = productosModel.traerTodos()

    return render_template('productos/index.html', productos = productos)

@app.route('/productos/crear', methods=['GET', 'POST'])
def crear_producto():
    # Esta funcion me sirve para mostrar el formulario de creacion
    # Y tambien me sirve para crear un nuevo producto
    # Estos pasos se identifican con los metodos  
    if request.method == 'GET':
        # Mostramos el formulario de creación
        return render_template('productos/crear.html')
    
    #Aca es la creación del producto
    nombre = request.form.get('nombre')
    descripcion = request.form.get('descripcion')
    pventa = request.form.get('pventa')
    pcompra = request.form.get('pcompra')
    estado = request.form.get('estado')
    ganancia = request.form.get('ganancia')

    productosModel = ProductosModel()

    productosModel.crear(nombre, descripcion, pventa, pcompra, estado, ganancia)

    return redirect(url_for('productos'))

@app.route('/productos/eliminar', methods=['GET', 'POST'])
def eliminar_producto():
    if request.method == 'GET':
        return render_template('productos/eliminar.html')

    nombre = request.form.get('nombre')

    productosModel = ProductosModel()

    productosModel.eliminar(nombre)

    return redirect(url_for('productos'))

@app.route("/productos/editar/<int:id>", methods=['GET', 'POST'])
def editar_producto(id):
    ProductosModelE = ProductosModel()
    if request.method == 'GET':
        productos = ProductosModelE.buscador(id)
        return render_template('productos/editar.html', productos=productos)
    id1 = request.form.get('id')
    nombre = request.form.get('nombre')
    descripcion = request.form.get('descripcion')
    pventa = request.form.get('pventa')
    pcompra = request.form.get('pcompra')
    estado = request.form.get('estado')
    ganancia = request.form.get('ganancia')

    productosModelE = ProductosModel()

    productosModelE.editar(nombre, descripcion, pventa, pcompra, estado, ganancia,id1)

    return redirect(url_for('productos'))
