from src.config.db import DB

class ProductosModel():
    def traerTodos(self):
        cursor = DB.cursor()

        cursor.execute('select * from productos')

        productos = cursor.fetchall()
        
        cursor.close()

        return productos
    
    def crear(self, nombre, descripcion, pventa, pcompra, estado, ganancia):
        cursor = DB.cursor()

        cursor.execute('insert into productos(nombre, descripcion, precio_de_venta, precio_de_compra, ganancia,estado ) values(?,?,?,?,?,?)', (nombre, descripcion, pventa, pcompra, ganancia, estado,))

        cursor.close()


    def eliminar(self, nombre):
        cursor = DB.cursor()

        cursor.execute('delete from productos WHERE nombre = ?', (nombre,))

        cursor.close()

    def buscador(self, id):
        cursor = DB.cursor()
        cursor.execute('select * from productos where id = ?',(id,))
        productos=cursor.fetchone()
        cursor.close()
        return productos

    def editar(self, nombre, descripcion, pventa, pcompra, estado, ganancia):
        cursor = DB.cursor()
        cursor.execute('update productos set nombre=?, descripcion=?, precio_de_venta=?, precio_de_compra=?, ganancia=?, estado=? where id=?',(nombre, descripcion, pventa,pcompra, ganancia, estado,id1))